

<?php
session_start();
if(isset($_SESSION['login'])){
?>










<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Car Record System</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/home.css">
  <link rel="shortcut icon" href="asset/logo.png" type="image/x-icon" id="favicon">
</head>
<body>
  <div class="container">
    <nav>
      <div class="logo">
        <img src="asset/logo.png" alt="" width="90px" id="logoimg">
      </div>
      <h1 id="unitName">
        53 EME Bn
      </h1>
      <h1><a href="logout.php" style="color:white">Logout</a></h1>
    </nav>
    <nav class="navtwo">
      <a href="home.php">Home</a>
      <a onclick="history.forward()">Forword</a>
      
    </nav>
    <main>
      <a href="vehicleDashboard.php?vehicle=A_vehicle"><div class="div1">A vehicle</div></a>
      <a href="vehicleDashboard.php?vehicle=B_vehicle"><div class="div2">B vehicle</div></a>
      <a href="vehicleDashboard.php?vehicle=C_vehicle"><div class="div3">C vehicle</div></a>
      <a href="notifications.php"><div class="div4">Notifications</div></a>
      <a href=""><div class="div4">Important Note</div></a>
    </main>
    <footer>
      <h3>Copyright © 2023 | All rights Reserved</h3>
    </footer>
  </div>
</body>
<script src="js/script.js"></script>
</html>




<?php
}else{
  echo "You cannot Access this page without logined";
}
?>