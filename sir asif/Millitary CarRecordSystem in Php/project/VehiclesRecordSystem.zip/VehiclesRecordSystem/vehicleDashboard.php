<?php
session_start();
if(isset($_SESSION['login'])){
?>











<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Car Record System</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/avehicle.css">
  <link rel="shortcut icon" href="asset/logo.png" type="image/x-icon"  id="favicon">
</head>
<body>
  <div class="container">
    <nav>
      <div class="logo">
        <img src="asset/logo.png" alt="" width="90px" id="logoimg">
      </div>
      <h1 id="unitName">
        53 EME Bn
      </h1>
      <h1><a href="logout.php" style="color:white">Logout</a></h1>
    </nav>
    <nav class="navtwo">
      <a href="home.php">Home</a>
      <a onclick="history.back()">Back</a>
      <a onclick="history.forward()">Forword</a>
      
    </nav>
    <br><br>
    <h1><?php echo $_GET['vehicle']; ?></h1>
    <br>

    <main>
      <a href="Addvehicle.php?vehicle=<?php echo $_GET['vehicle']; ?>"><div class="div1">Add vehicle</div></a>
      <a href="SDS.php?name=Search"><div class="div2">Search vehicle</div></a>
      <a href="SDS.php?name=Status"><div class="div3">vehicle Status</div></a>
      <a href="SDS.php?name=Delete"><div class="div4">Delete vehicle</div></a>
    </main>
    <hr>
    <main>
      <a href="vehicleChecks.php?check=Monthly"><div class="div1">Monthly Checks</div></a>
      <a href="vehicleChecks.php?check=Quaterly"><div class="div2">Quaterly Checks</div></a>
      <a href="vehicleChecks.php?check=Annual"><div class="div3">Annually Checks</div></a>
    </main>
    <footer>
      <h3>Copyright © 2023 | All rights Reserved</h3>
    </footer>
  </div>
</body>
<script src="js/script.js"></script>
</html>


<?php
}else{
  echo "You cannot Access this page without logined";
}
?>